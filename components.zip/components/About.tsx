"use client";

import { useRef, useState, useEffect } from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import SectionHeading from "@/components/SectionHeading";
import { luxuryEase } from "@/lib/animations";

const slides = [
  {
    kicker: "Our Philosophy & Craft",
    title: "We believe there is something profound in capturing real, unscripted emotion.",
    body: "Hi! We are husband and wife destination wedding photographers and filmmakers, Alex and Cassie. For over a decade we have documented love stories with an editorial, romantic eye.",
    image: "https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=1400&auto=format&fit=crop",
    badge: "Timeless & Cinema",
  },
  {
    kicker: "Around The World",
    title: "From the hills of Tuscany to the ch\u00e2teaux of France.",
    body: "What started as a shared passion for cinema and fine art has grown into a studio trusted by couples across five continents.",
    image: "https://images.unsplash.com/photo-1606800052052-a08af7148866?q=80&w=1400&auto=format&fit=crop",
    badge: "5 Continents",
  },
  {
    kicker: "Our Approach",
    title: "Fine-art portraiture meets documentary nostalgia.",
    body: "Whether an intimate gathering of twenty or a celebration of hundreds, we step into the moment up close and personal.",
    image: "https://images.unsplash.com/photo-1529636798458-92182e662485?q=80&w=1400&auto=format&fit=crop",
    badge: "Vogue & Magnolia Rouge",
  },
  {
    kicker: "Let\u2019s Begin",
    title: "Heirlooms that feel as cinematic fifty years from now.",
    body: "Top 30 Rising Stars of Wedding Photography, NYC. Tell us your date and we will tell you the story.",
    image: "https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?q=80&w=1400&auto=format&fit=crop",
    badge: "Top 30 \u00b7 NYC",
  },
];

const N = slides.length;
const COOLDOWN = 900;
const DELTA_THRESHOLD = 50;

export default function About() {
  const sectionRef = useRef<HTMLElement>(null);
  const [active, setActive] = useState(0);

  const activeRef = useRef(0);
  const lockedRef = useRef(false);
  const busyRef = useRef(false);
  const deltaRef = useRef(0);
  const timerRef = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  useEffect(() => { activeRef.current = active; }, [active]);

  /* ── Lock when section is ~fully visible ── */
  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => { lockedRef.current = e.isIntersecting && e.intersectionRatio > 0.85; },
      { threshold: [0, 0.5, 0.85, 1] },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  /* ── Wheel: intercept to cycle slides ── */
  useEffect(() => {
    const onWheel = (e: WheelEvent) => {
      if (!lockedRef.current) return;
      if (busyRef.current) { e.preventDefault(); e.stopImmediatePropagation(); return; }

      const down = e.deltaY > 0;
      const i = activeRef.current;

      // at boundaries → let normal scroll resume
      if (down && i >= N - 1) return;
      if (!down && i <= 0) return;

      e.preventDefault();
      e.stopImmediatePropagation();

      deltaRef.current += e.deltaY;
      if (timerRef.current) clearTimeout(timerRef.current);
      timerRef.current = setTimeout(() => { deltaRef.current = 0; }, 200);
      if (Math.abs(deltaRef.current) < DELTA_THRESHOLD) return;

      deltaRef.current = 0;
      busyRef.current = true;
      setActive((p) => Math.min(N - 1, Math.max(0, p + (down ? 1 : -1))));
      setTimeout(() => { busyRef.current = false; }, COOLDOWN);
    };

    window.addEventListener("wheel", onWheel, { passive: false, capture: true });
    return () => window.removeEventListener("wheel", onWheel, true);
  }, []);

  /* ── Touch support ── */
  useEffect(() => {
    let startY = 0;
    const onStart = (e: TouchEvent) => { if (lockedRef.current) startY = e.touches[0].clientY; };
    const onEnd = (e: TouchEvent) => {
      if (!lockedRef.current || busyRef.current) return;
      const dy = startY - e.changedTouches[0].clientY;
      if (Math.abs(dy) < 40) return;
      const down = dy > 0;
      const i = activeRef.current;
      if (down && i >= N - 1) return;
      if (!down && i <= 0) return;
      busyRef.current = true;
      setActive((p) => Math.min(N - 1, Math.max(0, p + (down ? 1 : -1))));
      setTimeout(() => { busyRef.current = false; }, COOLDOWN);
    };
    window.addEventListener("touchstart", onStart, { passive: true });
    window.addEventListener("touchend", onEnd, { passive: true });
    return () => { window.removeEventListener("touchstart", onStart); window.removeEventListener("touchend", onEnd); };
  }, []);

  const s = slides[active];

  return (
    <section
      ref={sectionRef}
      id="about"
      className="relative h-screen w-full bg-white text-[#111] overflow-hidden"
    >
      <div className="h-full flex items-center">
        <div className="max-w-7xl mx-auto px-6 sm:px-10 w-full grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-20 items-center">

          {/* ═══ Image column: clip-path reveal ═══ */}
          <div className="lg:col-span-6 relative aspect-[4/5] max-h-[70vh] w-full overflow-hidden rounded-2xl shadow-2xl">
            <AnimatePresence initial={false}>
              <motion.div
                key={active}
                className="absolute inset-0"
                initial={{ clipPath: "inset(100% 0% 0% 0%)", scale: 1.15 }}
                animate={{ clipPath: "inset(0% 0% 0% 0%)", scale: 1 }}
                exit={{ opacity: 0.4 }}
                transition={{ duration: 1.1, ease: luxuryEase }}
              >
                <div className="absolute inset-[-6%]">
                  <Image
                    src={s.image}
                    alt={s.title}
                    fill
                    sizes="(max-width: 1024px) 100vw, 50vw"
                    className="object-cover"
                    priority={active === 0}
                  />
                </div>
              </motion.div>
            </AnimatePresence>

            <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent pointer-events-none" />
            <span className="absolute bottom-5 left-5 font-serif italic text-white text-xl z-10">
              {s.badge}
            </span>
          </div>

          {/* ═══ Text column: blur-rise transition ═══ */}
          <div className="lg:col-span-6 flex flex-col gap-6 lg:pl-6 min-h-[360px] justify-center">
            <AnimatePresence mode="wait">
              <motion.div
                key={active}
                initial={{ opacity: 0, y: 40, filter: "blur(8px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                exit={{ opacity: 0, y: -30, filter: "blur(6px)" }}
                transition={{ duration: 0.7, ease: luxuryEase }}
                className="flex flex-col gap-6"
              >
                <span className="font-sans text-xs uppercase tracking-[0.28em] text-[#999] font-medium">
                  {s.kicker}
                </span>
                <h3 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-light leading-[1.2]">
                  {s.title}
                </h3>
                <p className="font-sans text-base sm:text-lg font-light text-[#666] leading-relaxed">
                  {s.body}
                </p>
                {active === N - 1 && (
                  <a
                    href="#contact"
                    className="self-start inline-flex px-8 py-4 bg-[#111] text-white text-xs uppercase tracking-[0.25em] rounded-full hover:bg-[#333] transition-colors duration-500"
                  >
                    Inquire For Your Date
                  </a>
                )}
              </motion.div>
            </AnimatePresence>

            {/* Progress */}
            <div className="flex items-center gap-4 mt-4">
              <span className="font-sans text-xs tabular-nums text-[#666]">
                {String(active + 1).padStart(2, "0")} / {String(N).padStart(2, "0")}
              </span>
              <div className="h-px flex-1 bg-black/10 relative overflow-hidden">
                <motion.div
                  className="absolute inset-y-0 left-0 bg-[#111]"
                  animate={{ width: `${((active + 1) / N) * 100}%` }}
                  transition={{ duration: 0.6, ease: luxuryEase }}
                />
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
