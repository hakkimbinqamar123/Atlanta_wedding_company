"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

const testimonials = [
  {
    id: 1,
    quote: "Alex and Cassie captured the absolute soul of our wedding day. When we watched our film, it felt like stepping into a cinematic dream. Every single guest asked who our artists were.",
    clientName: "Elena & Julian",
    weddingLocation: "Villa Balbiano, Lake Como",
  },
  {
    id: 2,
    quote: "Their gentle calm presence and extraordinary eye for lighting made all the difference during our sunset ceremony. The photos are timeless—soft, romantic, and imbued with genuine emotion.",
    clientName: "Amélie & Henri",
    weddingLocation: "Château de Chantilly, France",
  },
  {
    id: 3,
    quote: "We wanted imagery that felt like Vogue meets an heirloom family photo album. Atlanta Wedding Company exceeded every expectation. Their ability to catch quiet glances is unmatched.",
    clientName: "Victoria & James",
    weddingLocation: "Amalfi Coast, Italy",
  },
];

export default function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="testimonials" className="py-32 md:py-48 bg-[#111] text-[#EFECE6] relative flex flex-col items-center justify-center min-h-[70vh] overflow-hidden">
      {/* Cinematic subtle spotlight */}
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-[#D9B792] via-transparent to-transparent pointer-events-none" />

      <div className="max-w-5xl mx-auto px-6 relative z-10 text-center w-full">
        <p className="font-sans text-xs uppercase tracking-[0.4em] text-[#D9B792] mb-16">Kind Words</p>

        <div className="relative h-[320px] sm:h-[250px] w-full flex items-center justify-center">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
              className="absolute inset-0 flex flex-col items-center justify-center w-full"
            >
              <p className="font-serif italic text-2xl sm:text-4xl md:text-5xl font-light leading-[1.3] tracking-tight mb-12 max-w-4xl text-white">
                "{testimonials[currentIndex].quote}"
              </p>
              
              <div className="flex flex-col items-center gap-3">
                <span className="font-sans text-sm tracking-[0.2em] uppercase text-white/90">
                  {testimonials[currentIndex].clientName}
                </span>
                <span className="font-sans text-[10px] tracking-[0.3em] uppercase text-[#D9B792]">
                  {testimonials[currentIndex].weddingLocation}
                </span>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Progress Dots */}
        <div className="flex items-center justify-center gap-4 mt-20">
          {testimonials.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={`h-[1px] transition-all duration-700 ${idx === currentIndex ? "w-16 bg-[#D9B792]" : "w-6 bg-white/20 hover:bg-white/40"}`}
              aria-label={`Go to testimonial ${idx + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
