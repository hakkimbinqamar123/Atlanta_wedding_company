"use client";

import { useEffect, useLayoutEffect, useRef, useState } from "react";
import Image from "next/image";
import {
  motion,
  AnimatePresence,
  useScroll,
  useTransform,
  useSpring,
} from "framer-motion";
import SectionHeading from "@/components/SectionHeading";
import { luxuryEase } from "@/lib/animations";

type Photo = { src: string; label: string; portrait: boolean };

const u = (id: string) =>
  `https://images.unsplash.com/${id}?q=80&w=1200&auto=format&fit=crop`;

const photos: Photo[] = [
  { src: u("photo-1583089892943-e02e5b017b6a"), label: "Bridal Portrait", portrait: true },
  { src: u("photo-1609151376730-f246b0a142c7"), label: "Mehendi", portrait: false },
  { src: u("photo-1604604557976-25690e2bec34"), label: "The Groom", portrait: true },
  { src: u("photo-1591604466107-ec97de577aff"), label: "Haldi Ceremony", portrait: true },
  { src: u("photo-1610173826608-e8eb6c28da72"), label: "Bride To Be", portrait: false },
  { src: u("photo-1519741497674-611481863552"), label: "Wedding Vows", portrait: true },
  { src: u("photo-1606800052052-a08af7148866"), label: "Couple Portrait", portrait: true },
  { src: u("photo-1465495976277-4387d4b0b4c6"), label: "Golden Hour", portrait: false },
];

/* 1. Pinned horizontal strip: vertical scroll moves photos sideways.
   Travel distance is MEASURED (not hard-coded) so the last card always stops
   exactly at the right edge on every screen size. */
function FeaturedStrip() {
  const ref = useRef<HTMLDivElement>(null);
  const rowRef = useRef<HTMLDivElement>(null);
  const [travel, setTravel] = useState(0);

  useLayoutEffect(() => {
    const measure = () => {
      if (!rowRef.current) return;
      setTravel(Math.max(0, rowRef.current.scrollWidth - window.innerWidth));
    };
    measure();
    const ro = new ResizeObserver(measure);
    if (rowRef.current) ro.observe(rowRef.current);
    window.addEventListener("resize", measure);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, []);

  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });
  const p = useSpring(scrollYProgress, { stiffness: 90, damping: 26, mass: 0.4 });
  const x = useTransform(p, [0, 1], [0, -travel]);
  const bar = useTransform(p, [0, 1], [0, 1]);

  return (
    // scroll distance = horizontal travel + one screen, so speed feels 1:1
    <div ref={ref} className="relative" style={{ height: `calc(100vh + ${travel}px)` }}>
      <div className="sticky top-0 h-screen overflow-hidden">
        <motion.div
          ref={rowRef}
          style={{ x }}
          className="absolute inset-y-0 left-0 flex w-max items-center gap-[4vw] px-[8vw] will-change-transform"
        >
          {photos.map((ph, i) => (
            <div
              key={ph.src}
              // same size for all cards; alternate with translateY so the row stays
              // vertically centred and nothing is clipped
              className={`relative flex-none h-[58vh] aspect-[4/5] overflow-hidden rounded-2xl shadow-2xl ${
                i % 2 ? "translate-y-[6vh]" : "-translate-y-[4vh]"
              }`}
            >
              <Image src={ph.src} alt={ph.label} fill sizes="(max-width:768px) 60vw, 30vw" className="object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent" />
              <span className="absolute bottom-4 left-4 font-serif italic text-white text-xl">{ph.label}</span>
            </div>
          ))}
        </motion.div>
        <div className="absolute bottom-[7vh] left-[8vw] right-[8vw] h-px bg-black/10">
          <motion.div style={{ scaleX: bar }} className="h-px bg-[#111] origin-left" />
        </div>
      </div>
    </div>
  );
}

/* Column count follows the breakpoint (1 / 2 / 3) */
function useColumns() {
  const [cols, setCols] = useState(3);
  useEffect(() => {
    const calc = () => setCols(window.innerWidth >= 1024 ? 3 : window.innerWidth >= 640 ? 2 : 1);
    calc();
    window.addEventListener("resize", calc);
    return () => window.removeEventListener("resize", calc);
  }, []);
  return cols;
}

/* 2. Balanced masonry + lightbox */
function Archive() {
  const [open, setOpen] = useState<number | null>(null);
  const n = photos.length;
  const cols = useColumns();

  // Greedy shortest-column placement => even column heights, left-to-right reading order
  const columns: number[][] = Array.from({ length: cols }, () => []);
  const heights = Array(cols).fill(0);
  photos.forEach((ph, i) => {
    const c = heights.indexOf(Math.min(...heights));
    columns[c].push(i);
    heights[c] += ph.portrait ? 1.25 : 0.8;
  });

  useEffect(() => {
    if (open === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(null);
      if (e.key === "ArrowRight") setOpen((i) => (i! + 1) % n);
      if (e.key === "ArrowLeft") setOpen((i) => (i! - 1 + n) % n);
    };
    // lock page scroll WITHOUT the layout jump caused by the vanishing scrollbar
    const gap = window.innerWidth - document.documentElement.clientWidth;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    document.body.style.paddingRight = `${gap}px`;
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prevOverflow;
      document.body.style.paddingRight = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open, n]);

  return (
    <>
      <div className="group/grid max-w-6xl mx-auto px-6 sm:px-10 flex gap-5 items-start">
        {columns.map((col, ci) => (
          <div key={ci} className="flex-1 min-w-0 flex flex-col gap-5">
            {col.map((i) => {
              const ph = photos[i];
              return (
                <button
                  key={ph.src}
                  onClick={() => setOpen(i)}
                  className="group relative block w-full overflow-hidden rounded-xl cursor-zoom-in transition-[filter] duration-500 group-hover/grid:brightness-75 hover:!brightness-100"
                >
                  <div className={`relative w-full ${ph.portrait ? "aspect-[4/5]" : "aspect-[5/4]"}`}>
                    <Image
                      src={ph.src}
                      alt={ph.label}
                      fill
                      sizes="(max-width:640px) 100vw, (max-width:1024px) 50vw, 33vw"
                      className="object-cover transition-transform duration-1000 ease-out group-hover:scale-105"
                    />
                  </div>
                  <span className="absolute bottom-3 left-4 font-serif italic text-white text-lg opacity-0 translate-y-2 transition-all duration-500 group-hover:opacity-100 group-hover:translate-y-0">
                    {ph.label}
                  </span>
                </button>
              );
            })}
          </div>
        ))}
      </div>

      <AnimatePresence>
        {open !== null && (
          <motion.div
            data-lenis-prevent
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center overscroll-contain"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
            onClick={() => setOpen(null)}
          >
            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                key={open}
                initial={{ opacity: 0, scale: 0.94 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.5, ease: luxuryEase }}
                // size follows the photo's own ratio; fits any viewport
                className={`relative max-h-[80vh] max-w-[88vw] rounded-lg overflow-hidden ${
                  photos[open].portrait ? "aspect-[4/5] h-[80vh]" : "aspect-[5/4] w-[min(88vw,100vh)]"
                }`}
                onClick={(e) => e.stopPropagation()}
              >
                <Image src={photos[open].src} alt={photos[open].label} fill sizes="90vw" className="object-cover" priority />
              </motion.div>
            </AnimatePresence>

            {[
              { d: -1, cls: "left-3 sm:left-8", t: "←", l: "Previous" },
              { d: 1, cls: "right-3 sm:right-8", t: "→", l: "Next" },
            ].map((b) => (
              <button
                key={b.l}
                aria-label={b.l}
                onClick={(e) => {
                  e.stopPropagation();
                  setOpen((open + b.d + n) % n);
                }}
                className={`absolute top-1/2 -translate-y-1/2 ${b.cls} h-12 w-12 rounded-full border border-white/30 bg-black/30 text-white hover:bg-white/10 transition-colors`}
              >
                {b.t}
              </button>
            ))}
            <button
              aria-label="Close"
              onClick={() => setOpen(null)}
              className="absolute top-5 right-4 sm:right-8 h-12 w-12 rounded-full border border-white/30 bg-black/30 text-white hover:bg-white/10 transition-colors"
            >
              ✕
            </button>
            <p className="absolute bottom-6 text-xs tracking-[0.2em] text-white/60">
              {photos[open].label.toUpperCase()} · {open + 1} / {n}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

export default function Gallery() {
  return (
    // no overflow-hidden on this section or any parent: it would break position: sticky
    <section id="gallery" className="bg-white text-[#111]">
      <div className="max-w-7xl mx-auto px-6 sm:px-10 pt-28 md:pt-40 pb-12">
        <SectionHeading smallHeading="PORTFOLIO" largeHeading="Stories We Have Been Trusted To Tell" />
      </div>
      <FeaturedStrip />
      <div className="pt-24 pb-28 md:pt-32 md:pb-40">
        <Archive />
      </div>
    </section>
  );
}
