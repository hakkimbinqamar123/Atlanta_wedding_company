"use client";

import Link from "next/link";
import { ArrowUpRight } from "lucide-react";

export default function Footer() {
  const scrollToTop = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="bg-[#0a0a0a] text-white py-24 md:py-32 border-t border-white/5 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 sm:px-10 flex flex-col items-center text-center">
        
        {/* Massive Bold Typography */}
        <Link href="#home" onClick={scrollToTop} className="group relative z-10 block mb-24 cursor-pointer focus:outline-none">
          <h2 className="font-serif text-[12vw] leading-none tracking-tighter font-light text-white opacity-90 group-hover:opacity-100 transition-opacity duration-700">
            ATLANTA
          </h2>
          <h2 className="font-serif italic text-[7vw] leading-none tracking-tight font-light text-[#D9B792] group-hover:text-white transition-colors duration-700 -mt-2 sm:-mt-6">
            Wedding Co.
          </h2>
        </Link>

        {/* Navigation Links */}
        <nav aria-label="Footer Navigation" className="flex flex-wrap items-center justify-center gap-8 sm:gap-16 mb-20 z-10">
          {[
            { name: "Home", href: "#home" },
            { name: "About", href: "#about" },
            { name: "Portfolio", href: "#portfolio" },
            { name: "Testimonials", href: "#testimonials" },
            { name: "Contact", href: "#contact" },
          ].map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className="font-sans text-xs uppercase tracking-[0.3em] text-white/70 hover:text-[#D9B792] transition-colors duration-300"
            >
              {item.name}
            </Link>
          ))}
        </nav>

        {/* Social & Direct Contact Links */}
        <div className="flex flex-wrap items-center justify-center gap-12 sm:gap-20 mb-20 pt-12 border-t border-white/10 w-full max-w-4xl z-10">
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            className="group flex items-center gap-3 font-sans text-xs uppercase tracking-[0.25em] text-white/90 hover:text-[#D9B792] transition-colors"
          >
            <span>Instagram</span>
            <ArrowUpRight className="w-4 h-4 opacity-50 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
          </a>

          <a
            href="mailto:inquire@atlantaweddingcompany.com"
            className="group flex items-center gap-3 font-sans text-xs uppercase tracking-[0.25em] text-white/90 hover:text-[#D9B792] transition-colors"
          >
            <span>inquire@atlantaweddingcompany.com</span>
            <ArrowUpRight className="w-4 h-4 opacity-50 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
          </a>
        </div>

        {/* Copyright & Location Note */}
        <div className="flex flex-col sm:flex-row items-center justify-between w-full pt-8 border-t border-white/10 text-white/40 font-sans text-[10px] uppercase tracking-[0.25em] gap-6 z-10">
          <p>© {new Date().getFullYear()} ATLANTA WEDDING COMPANY.</p>
          <p className="text-[#D9B792]/60">Fine Art Cinema • Available Worldwide</p>
        </div>
      </div>
    </footer>
  );
}
